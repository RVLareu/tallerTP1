# tallerTP1
Taller de programación - Veiga - 2021 2C

## Falta corregirlo casi todo, intento llegar a reentrega.
